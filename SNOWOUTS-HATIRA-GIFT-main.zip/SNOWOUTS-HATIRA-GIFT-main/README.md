# SNOWOUTS-HATIRA-GIFT
Snow Kardeşimin anısına ona hazırladığım v13 projedir. Bir Fatiha okursunuz.
